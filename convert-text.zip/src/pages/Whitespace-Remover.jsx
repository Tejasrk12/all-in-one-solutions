import React from 'react';

export default function WhitespaceRemover(){
    return(
        <>
        <h1>Whitespace Remover</h1>
        </>
    )
}
