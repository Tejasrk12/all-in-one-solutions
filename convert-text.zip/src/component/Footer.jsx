import React from 'react'

export default function Footer(){
    return(
        <>
        <footer>
            <div className='flex justify-center bg-primary py-2'>
                <p className='text-white text-[14px]'>Designed by Tejas</p>
            </div>
        </footer>
        </>
    )
}